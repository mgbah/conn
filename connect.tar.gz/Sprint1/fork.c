#include <stdio.h>
#include <stdlib.h>
/*Author michal musialik*/
/*fork with parrent and child that return pid*/

int main(void){

  /*initicazing variable*/
  int ret = fork();

  /*child with pid*/
  if (ret == 0){
    printf("This is a child with pid %i\n",getpid());
  }
  /*parrent with pid*/
  else{
    printf("This is a parrent with pid %i\n",getpid());
  }
  return 0;
}
