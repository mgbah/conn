#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int i;
  double d;
  long l;

  i = atoi("1");
  l = atol("11111111");
  d = atof("11111.11111");

  printf("%d\n %ld\n %f\n", i, l, d);

  return 0;
}
