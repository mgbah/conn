#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024
#define PORT 9600
#define SENDS 10

/*author michal musialik*/
/*starting by printing an ip adress you want to connect to*/
int main(int argc, char **argv){

  /*initiazing variables*/
  int udp_client;
  struct sockaddr_in server;
  struct hostent *host;
  /*print out message*/
  char data[BUFFER_SIZE] = "Some message";
  int i;

  /*information about host you connect to*/
  host = (struct hostent *)gethostbyname((char *) argv[1]);
  printf("Connecting to %s\n", argv[1]);
  
  /*socket*/
  udp_client = socket(AF_INET, SOCK_DGRAM, 0);
  if(udp_client < 0){
    perror("Cannot make a socket\n");
    exit(EXIT_FAILURE);
  }
  else{
    printf("Creating a socket\n");
  }
  /*server information*/
  server.sin_family = AF_INET;
  server.sin_port = htons(PORT);
  server.sin_addr = *((struct in_addr *)host->h_addr);

  /*sending 10 messages to the server wijt 2 sec interval*/
  /*
  for (i = 0;i <= SENDS; i++){
  
      sendto(udp_client, data, BUFFER_SIZE, 0, (struct sockaddr*)&server, sizeof(struct sockaddr) );
    sleep(2);
      
 }

  */

 while (1)
   {

    printf("Type a message or 'quit' to quit");
    scanf("%s", data);

    if ((strcmp(data , "quit")) == 0){
       break;
      }
    else
       sendto(udp_client, data, strlen(data), 0,
              (struct sockaddr *)&server, sizeof(struct sockaddr));
     
   }


  close(udp_client); 
  return 0;
}
