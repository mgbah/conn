#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
/*Author michal musialik*/
/*This is a fork that create udp/tcp sockets in 2 different processes*/


int socket(int af, int type, int protocol);

int main(void){

  /*variable initiation*/
  int socket_tcp;
  int socket_udp;
  
  /*creating tcp and udp sockets*/
  socket_tcp=socket(AF_INET, SOCK_STREAM, 0);
  socket_udp=socket(AF_INET, SOCK_DGRAM, 0);  
 
  
  /*creating tcp socket*/
  if (socket_tcp == -1){
    
    perror("Create socket\n");
  }
  else{
    
    printf("Created tcp socket\n");
    
  }
  /*creating udp socket*/
  if(socket_udp == -1){
    perror("Create socket\n");
  }
  else{
    printf("Created udp socket\n");
  }

  return 0;
  
}
