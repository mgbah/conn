#include <stdio.h>
#include<string.h>
#include<stdlib.h>

int state = 1;
int check()
{
return state;
}

int inc()
{
return state+=1;
printf("the state is %d\n",state);
}


