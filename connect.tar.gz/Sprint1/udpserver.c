#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>
/*mask module*/
#include "mask.c"


#define PORT 9600
#define BUFFER_SIZE 1024
#define IP_BUFFER 200
/*author michal musialik*/

int main(void){

  /*variable initaizing*/
  int udp_socket;
  int binding;
  int eth;
  int size;
  int receive_data;
  char buffer[BUFFER_SIZE];
  char ip[IP_BUFFER];
  int temp;
 
 /*structen for sockets*/
  struct sockaddr_in server;
  struct sockaddr_in client;
  struct hostent * Host ;

  /*Getting information about host name and ip adress*/
  gethostname ( ip , IP_BUFFER ) ;
  printf ( "%s\n", ip ) ;
  Host = ( struct hostent * ) gethostbyname ( ip ) ;
  printf ( "The name :: %s\n" , Host->h_name ) ;
  printf("IP Address : %s\n", inet_ntoa(*((struct in_addr *)Host->h_addr)));

  /*creating a socket*/
  udp_socket = socket(AF_INET, SOCK_DGRAM,0);

  /*returning -1 if cant be created*/
  if(udp_socket < 0){
    perror("Cant create socket\n");
    exit(EXIT_FAILURE);
  }
  else{
    printf("Creating socket\n");
  }

  /*server information*/
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons(PORT);

  /*biding socket*/
  binding = bind (udp_socket,(struct sockaddr *)&server, sizeof(struct sockaddr));

  /*returning -1 if cant be created*/
  if(binding < 0){
    perror("Cannot bind socket\n");
    exit(EXIT_FAILURE);
  }
  else{
    printf("Binding socket\n");
  }

  /*byte sizen of recived socket*/
  size = sizeof(struct sockaddr);
 
  /*printing output untill server receive close command*/
  while(1){
 
   receive_data = recvfrom(udp_socket, buffer, BUFFER_SIZE, 0 , (struct sockaddr *)&client, &size);
   
    buffer[receive_data] = '\0';
    
    /*printing client adress and port*/
     printf("\n(%s , %d) said : ",inet_ntoa(client.sin_addr),
	   ntohs(client.sin_port));
    printf("%s", buffer);
    
    /*coneverting string to integer*/
    temp = atoi(buffer);
    /*part of mask.c module where different valued are calculated*/
    onMask(temp);
    maskThrust(temp);
    maskDegree(temp);z   
  }
  
  /*closing socket*/
  close(udp_socket);
  return 0;
}
