#include <stdio.h>

/*Masks for gathering different parts of bin-code*/

#define ON_MASK 1
#define THRUST_MASK 126 
#define DEGREE_MASK 384

/*Mask for power*/
void onMask(unsigned int power){

  /*printing incomming value*/
  printf("Power value in %u\n", power);

  /*doing multiplication with ON_MASK*/
  power = power & ON_MASK;

  /*result after mask*/
  printf("Power after mask %u\n", power);

  /*printing results*/
  if(power == 1){
    printf("Power is on %u\n", power );
  }
  else{
    printf("Power is off %u\n", power);
  }
  printf("\n");
}

/*Mask for thrust*/
maskThrust (unsigned int thrust){
    
  char per = '%';

  /*printing value in for thrust*/
  printf("value in thrust %u\n",thrust);

  /*doing multiplication with THRUST_MASK*/
  thrust = thrust & THRUST_MASK;

  /*printing the results*/
  printf("Thrust after mask %u%c\n", thrust,per);

  /*Shifting 1 step to the right*/
  thrust = thrust >> 1;

  /*dysplaing the results*/
  if(thrust > 100){
    printf("Thrust is more then 100%c \n",per);
  }
  else{
    printf("Thrust is  after shift %u%c \n\n",thrust,per);
  }
  
}

/*Mask for degrees*/
maskDegree(unsigned int degree){

  /*printing the incomming value for degres*/
  printf("degree %u\n", degree);

  /*doing multiplication with DEGREE_MASK*/
  degree = degree & DEGREE_MASK;

  /*printing results*/
  printf("degree after mask %u\n", degree);

  /*Shifting 7 steps to the right*/
  degree = degree >> 7;

  /*printing the results*/
  if(degree == 0){
    printf("0 degress %u\n", degree);
  }
  else if(degree == 1){
    printf("10 degrees %u\n", degree);
  }
  else if(degree == 2){
    printf("20 degree %u\n", degree);
  }
  else if(degree == 3){
    printf("30 degree %u\n", degree);
  }

}

/*
int main(void){

 
  int x = 385;
  int y = 401;


  onMask(x);
  maskThrust(x);
  maskDegree(x);
  
  onMask(y);
  maskThrust(y);
  maskDegree(y);

  return 0;
}
*/
