#include <stdio.h>
#include <string.h>

#define LOGIN "admin"

/*author michal musialik*/

/*login*/

int main(int argc,char **argv){

  /*comparing input with actual access*/
  if(strcmp(argv[1],LOGIN)!=0){
    printf("Access denied\n");//printing denided message

  }
  else{
    printf("Access graded\n");//printing sucess message
  }

  return 0;
}
