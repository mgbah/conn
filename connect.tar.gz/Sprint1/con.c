#include <stdio.h>

void print_bits(int a);

int main(void){

  int a;

  printf("Enter a number");
  scanf("%i",&a);

  printf("Hex:%.10x Dec: %.12d  Oct: %.14o  Bin:\n",a,a,a);

 void print_bits(int a)
  {
    unsigned int mask = 1<<(sizeof(a) * 8 - 1);
    int tmp;
    int i = 0;

    while (mask>0)
      {
	tmp = a & mask ;
	if ( tmp != 0 ) { tmp = 1 ; }
	if (i++%8==0) printf (" ");
	printf ("%d", tmp);
	mask >>= 1;
      }
    return;
  }

  print_bits(a);
  printf("\n");

  return 0;
}
