#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Author michal musialik*/

/*A linux method to check for you local ip*/
/*You run by selecting with eth your running*/ 
/*this program is only runable in windows*/

int main(int argc, char **argv){

  if(strcmp(argv[1],"eth0") == 0){
    /*running command ifconfig for eth0*/ 
    system("ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'");
  }
  else{
    /*running command ipconfig for eth1*/   
    system("ifconfig eth1 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'");
  }
  return 0;
}
